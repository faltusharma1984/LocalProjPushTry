package com.sukh.learnspark

import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf

/**
 * @author ${user.name}
 */
object App {

  def main(args : Array[String]) {
    
    println("===========hello==========")
    val conf = new SparkConf()
      .setAppName("The swankiest Spark app ever")
      .setMaster("local[2]")

    val sc = new SparkContext(conf)

    /*val col = sc.parallelize(0 to 100 by 5)
    val smp = col.sample(true, 4)
    val colCount = col.count
    val smpCount = smp.count
    
    println("orig count = " + colCount)
    println("sampled count = " + smpCount)*/
    
    val testFile = sc.textFile("F:\\spark\\wordcountexample\\data\\sampleData.txt")
    println("count of rows =" + testFile.count())
     println("first row=" + testFile.first())
     
    // testFile.flatMap(line=>line.split(" ")).map(word=>(word,1)).reduceByKey(_+_).saveAsTextFile("file:///F/spark/wordcountexample/data/HelloWorld5")
     testFile.flatMap(line=>line.split(" ")).map(word=>(word,1)).reduceByKey(_+_).saveAsTextFile("F:\\spark\\wordcountexample\\data\\HelloWorld6")
     
  }

}
